import React, { useState } from 'react';
import { OnboardingHome } from './components/OnboardingHome';
import { TripPlanning } from './components/TripPlanning';
import { ItineraryPage } from './components/ItineraryPage';
import { SafetyDashboard } from './components/SafetyDashboard';

export type Screen = 'onboarding' | 'home' | 'trip-planning' | 'itinerary' | 'safety';

export interface TripData {
  destination: string;
  startDate: string;
  endDate: string;
  interests: string[];
  travelGoals: string[];
  age: string;
  gender: string;
  origin: string;
  medicalIssues: string;
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('onboarding');
  const [tripData, setTripData] = useState<TripData | null>(null);

  const navigateToScreen = (screen: Screen) => {
    setCurrentScreen(screen);
  };

  const handleTripDataSubmit = (data: TripData) => {
    setTripData(data);
    setCurrentScreen('itinerary');
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'onboarding':
      case 'home':
        return <OnboardingHome onNavigate={navigateToScreen} />;
      case 'trip-planning':
        return <TripPlanning onSubmit={handleTripDataSubmit} onBack={() => setCurrentScreen('home')} />;
      case 'itinerary':
        return <ItineraryPage tripData={tripData} onBack={() => setCurrentScreen('home')} onNavigate={navigateToScreen} />;
      case 'safety':
        return <SafetyDashboard onBack={() => setCurrentScreen('home')} />;
      default:
        return <OnboardingHome onNavigate={navigateToScreen} />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <style>{`
        :root {
          --nomad-dark-gray: #36454F;
          --nomad-saffron: #FF9933;
          --nomad-green: #008000;
          --nomad-blue: #0000FF;
        }
      `}</style>
      {renderScreen()}
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { MapPin, Shield, BookOpen, Compass, Menu, Bell } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import nomadLogo from 'figma:asset/da8a69c25a843853b6610714379cc001c45d55c6.png';

interface OnboardingHomeProps {
  onNavigate: (screen: 'trip-planning' | 'safety') => void;
}

export function OnboardingHome({ onNavigate }: OnboardingHomeProps) {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  if (showSplash) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#36454F] to-[#2a3540] text-white px-6">
        <div className="text-center mb-8">
          <div className="w-24 h-24 flex items-center justify-center mx-auto mb-6">
            <img src={nomadLogo} alt="NomadBharat" className="w-24 h-24 object-contain" />
          </div>
          <h1 className="text-4xl font-bold mb-2 text-white">NomadBharat</h1>
          <p className="text-lg text-gray-200">Journeys that tell India's story</p>
        </div>
        <div className="w-8 h-8 border-4 border-[#FF9933] border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#36454F] text-white px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 flex items-center justify-center">
            <img src={nomadLogo} alt="NomadBharat" className="w-8 h-8 object-contain" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-white">NomadBharat</h1>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Bell className="w-6 h-6 text-white" />
          <Menu className="w-6 h-6 text-white" />
        </div>
      </header>

      {/* Hero Section */}
      <div className="px-4 py-8 bg-gradient-to-r from-[#36454F] to-[#2a3540] text-white">
        <h2 className="text-2xl font-bold mb-2 text-white">Welcome to India!</h2>
        <p className="text-gray-200 mb-6">Plan your perfect journey with AI-powered recommendations</p>
        
        <Button
          onClick={() => onNavigate('trip-planning')}
          className="w-full bg-[#FF9933] hover:bg-[#e6851f] text-white py-4 text-lg font-semibold rounded-lg"
        >
          Plan Your Trip
        </Button>
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-6">
        <h3 className="text-lg font-semibold text-[#36454F] mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-4">
          <Card 
            className="p-4 border border-gray-200 hover:border-[#FF9933] transition-colors cursor-pointer"
            onClick={() => onNavigate('safety')}
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-3">
                <Shield className="w-6 h-6 text-red-600" />
              </div>
              <h4 className="font-semibold text-[#36454F] mb-1">Safety & Advisories</h4>
              <p className="text-sm text-gray-600">Stay safe during your travels</p>
            </div>
          </Card>

          <Card className="p-4 border border-gray-200 hover:border-[#FF9933] transition-colors cursor-pointer">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                <BookOpen className="w-6 h-6 text-[#0000FF]" />
              </div>
              <h4 className="font-semibold text-[#36454F] mb-1">My Itineraries</h4>
              <p className="text-sm text-gray-600">View saved trip plans</p>
            </div>
          </Card>
        </div>
      </div>

      {/* Featured Destinations */}
      <div className="px-4 py-6 bg-gray-50">
        <h3 className="text-lg font-semibold text-[#36454F] mb-4">Featured Destinations</h3>
        <div className="space-y-3">
          <Card className="p-4 border border-gray-200">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gradient-to-br from-[#FF9933] to-[#e6851f] rounded-lg flex items-center justify-center">
                <MapPin className="w-8 h-8 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-[#36454F]">Golden Triangle</h4>
                <p className="text-sm text-gray-600">Delhi • Agra • Jaipur</p>
                <p className="text-xs text-[#008000] mt-1">7-10 days recommended</p>
              </div>
            </div>
          </Card>

          <Card className="p-4 border border-gray-200">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gradient-to-br from-[#008000] to-[#006600] rounded-lg flex items-center justify-center">
                <MapPin className="w-8 h-8 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-[#36454F]">Kerala Backwaters</h4>
                <p className="text-sm text-gray-600">Kochi • Alleppey • Munnar</p>
                <p className="text-xs text-[#008000] mt-1">5-7 days recommended</p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Local Gems Section */}
      <div className="px-4 py-6">
        <h3 className="text-lg font-semibold text-[#36454F] mb-4">Local Gems</h3>
        <Card className="p-4 border border-gray-200 bg-gradient-to-r from-[#FF9933]/10 to-[#008000]/10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-[#FF9933] rounded-full flex items-center justify-center">
              <Compass className="w-5 h-5 text-white" />
            </div>
            <div>
              <h4 className="font-semibold text-[#36454F]">Hidden Experiences</h4>
              <p className="text-sm text-gray-600">Discover authentic local culture</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { ArrowLeft, Calendar, MapPin, User, Heart, Target, Globe, Activity, Plus, X } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { TripData } from '../App';

interface TripPlanningProps {
  onSubmit: (data: TripData) => void;
  onBack: () => void;
}

export function TripPlanning({ onSubmit, onBack }: TripPlanningProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<TripData>>({
    interests: [],
    travelGoals: []
  });

  const interestOptions = [
    'History & Heritage',
    'Food & Cuisine',
    'Adventure Sports',
    'Wildlife & Nature',
    'Spiritual & Wellness',
    'Art & Culture',
    'Photography',
    'Local Markets',
    'Festivals',
    'Architecture'
  ];

  const goalOptions = [
    'Cultural Immersion',
    'Relaxation & Wellness',
    'Adventure & Thrills',
    'Learning & Education',
    'Photography & Content',
    'Meeting Locals',
    'Budget Travel',
    'Luxury Experience'
  ];

  const updateFormData = (field: keyof TripData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleArrayItem = (field: 'interests' | 'travelGoals', item: string) => {
    const currentArray = formData[field] || [];
    const newArray = currentArray.includes(item)
      ? currentArray.filter(i => i !== item)
      : [...currentArray, item];
    updateFormData(field, newArray);
  };

  const handleSubmit = () => {
    if (step < 4) {
      setStep(step + 1);
    } else {
      onSubmit(formData as TripData);
    }
  };

  const canProceed = () => {
    switch (step) {
      case 1:
        return formData.destination && formData.startDate && formData.endDate;
      case 2:
        return (formData.interests?.length || 0) >= 3;
      case 3:
        return (formData.travelGoals?.length || 0) >= 2;
      case 4:
        return formData.age && formData.gender && formData.origin;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#36454F] text-white px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <button onClick={onBack} className="flex items-center space-x-2">
          <ArrowLeft className="w-5 h-5 text-white" />
          <span className="text-white">Back</span>
        </button>
        <h1 className="text-lg font-semibold text-white">Plan Your Trip</h1>
        <div className="text-sm text-gray-300">Step {step}/4</div>
      </header>

      {/* Progress Bar */}
      <div className="bg-gray-200 h-2">
        <div 
          className="bg-[#FF9933] h-2 transition-all duration-300"
          style={{ width: `${(step / 4) * 100}%` }}
        />
      </div>

      <div className="px-4 py-6">
        {/* Step 1: Destination & Dates */}
        {step === 1 && (
          <Card className="p-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-[#FF9933] rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-xl font-semibold text-[#36454F] mb-2">Where to?</h2>
              <p className="text-gray-600">Tell us your destination and travel dates</p>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="destination" className="text-[#36454F]">Destination in India</Label>
                <Input
                  id="destination"
                  placeholder="e.g., Rajasthan, Kerala, Golden Triangle"
                  value={formData.destination || ''}
                  onChange={(e) => updateFormData('destination', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="startDate" className="text-[#36454F]">Start Date</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={formData.startDate || ''}
                    onChange={(e) => updateFormData('startDate', e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="endDate" className="text-[#36454F]">End Date</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={formData.endDate || ''}
                    onChange={(e) => updateFormData('endDate', e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Step 2: Interests */}
        {step === 2 && (
          <Card className="p-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-[#FF9933] rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-xl font-semibold text-[#36454F] mb-2">What interests you?</h2>
              <p className="text-gray-600">Select at least 3 interests (tap to select)</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {interestOptions.map((interest) => (
                <button
                  key={interest}
                  onClick={() => toggleArrayItem('interests', interest)}
                  className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                    formData.interests?.includes(interest)
                      ? 'border-[#FF9933] bg-[#FF9933]/10 text-[#FF9933]'
                      : 'border-gray-200 text-gray-700 hover:border-[#FF9933]/50'
                  }`}
                >
                  {interest}
                </button>
              ))}
            </div>

            <div className="mt-4 text-center">
              <p className="text-sm text-gray-600">
                Selected: {formData.interests?.length || 0} interests
              </p>
            </div>
          </Card>
        )}

        {/* Step 3: Travel Goals */}
        {step === 3 && (
          <Card className="p-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-[#FF9933] rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-xl font-semibold text-[#36454F] mb-2">Travel Goals</h2>
              <p className="text-gray-600">What do you want to achieve? (Select at least 2)</p>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {goalOptions.map((goal) => (
                <button
                  key={goal}
                  onClick={() => toggleArrayItem('travelGoals', goal)}
                  className={`p-4 rounded-lg border-2 text-left font-medium transition-all ${
                    formData.travelGoals?.includes(goal)
                      ? 'border-[#FF9933] bg-[#FF9933]/10 text-[#FF9933]'
                      : 'border-gray-200 text-gray-700 hover:border-[#FF9933]/50'
                  }`}
                >
                  {goal}
                </button>
              ))}
            </div>

            <div className="mt-4 text-center">
              <p className="text-sm text-gray-600">
                Selected: {formData.travelGoals?.length || 0} goals
              </p>
            </div>
          </Card>
        )}

        {/* Step 4: Personal Details */}
        {step === 4 && (
          <Card className="p-6">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-[#FF9933] rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-xl font-semibold text-[#36454F] mb-2">Personal Details</h2>
              <p className="text-gray-600">Help us personalize your experience</p>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="age" className="text-[#36454F]">Age Range</Label>
                  <select
                    id="age"
                    value={formData.age || ''}
                    onChange={(e) => updateFormData('age', e.target.value)}
                    className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:border-[#FF9933] focus:outline-none"
                  >
                    <option value="">Select age</option>
                    <option value="18-25">18-25</option>
                    <option value="26-35">26-35</option>
                    <option value="36-45">36-45</option>
                    <option value="46-55">46-55</option>
                    <option value="55+">55+</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="gender" className="text-[#36454F]">Gender</Label>
                  <select
                    id="gender"
                    value={formData.gender || ''}
                    onChange={(e) => updateFormData('gender', e.target.value)}
                    className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:border-[#FF9933] focus:outline-none"
                  >
                    <option value="">Select gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                    <option value="prefer-not-to-say">Prefer not to say</option>
                  </select>
                </div>
              </div>

              <div>
                <Label htmlFor="origin" className="text-[#36454F]">Country of Origin</Label>
                <Input
                  id="origin"
                  placeholder="e.g., United States, United Kingdom"
                  value={formData.origin || ''}
                  onChange={(e) => updateFormData('origin', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="medical" className="text-[#36454F]">Medical Considerations (Optional)</Label>
                <Textarea
                  id="medical"
                  placeholder="Any dietary restrictions, allergies, or medical needs we should consider..."
                  value={formData.medicalIssues || ''}
                  onChange={(e) => updateFormData('medicalIssues', e.target.value)}
                  className="mt-1"
                  rows={3}
                />
              </div>
            </div>
          </Card>
        )}

        {/* Navigation Buttons */}
        <div className="mt-6 flex space-x-3">
          {step > 1 && (
            <Button
              onClick={() => setStep(step - 1)}
              variant="outline"
              className="flex-1 border-[#36454F] text-[#36454F] hover:bg-[#36454F] hover:text-white"
            >
              Previous
            </Button>
          )}
          <Button
            onClick={handleSubmit}
            disabled={!canProceed()}
            className={`flex-1 font-semibold ${
              canProceed()
                ? 'bg-[#FF9933] hover:bg-[#e6851f] text-white'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            {step === 4 ? 'Generate My Itinerary' : 'Next'}
          </Button>
        </div>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { ArrowLeft, Download, MapPin, Clock, Star, Camera, Utensils, Coffee, Gem, Calendar, Share } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { toast } from 'sonner@2.0.3';
import { TripData } from '../App';

interface ItineraryPageProps {
  tripData: TripData | null;
  onBack: () => void;
  onNavigate: (screen: 'safety') => void;
}

export function ItineraryPage({ tripData, onBack, onNavigate }: ItineraryPageProps) {
  const [expandedDay, setExpandedDay] = useState<number | null>(1);

  const handleDownloadPDF = () => {
    toast("PDF downloaded successfully! Your itinerary is now available offline.", {
      duration: 3000,
      style: {
        background: '#008000',
        color: 'white',
      }
    });
  };

  const handleShareItinerary = () => {
    toast("Itinerary shared successfully!", {
      duration: 2000,
      style: {
        background: '#FF9933',
        color: 'white',
      }
    });
  };

  // Mock itinerary data based on user input
  const generateItinerary = () => {
    if (!tripData) return [];

    const baseItinerary = [
      {
        day: 1,
        title: "Arrival & Local Exploration",
        location: tripData.destination,
        activities: [
          {
            time: "10:00 AM",
            title: "Airport Pickup & Hotel Check-in",
            description: "Welcome to India! Private transfer to your hotel.",
            type: "transport",
            isHiddenGem: false
          },
          {
            time: "2:00 PM",
            title: "Local Market Walking Tour",
            description: "Explore authentic local markets and try street food.",
            type: "culture",
            isHiddenGem: true
          },
          {
            time: "6:00 PM",
            title: "Traditional Welcome Dinner",
            description: "Experience regional cuisine at a family-run restaurant.",
            type: "food",
            isHiddenGem: true
          }
        ]
      },
      {
        day: 2,
        title: "Cultural Immersion Day",
        location: tripData.destination,
        activities: [
          {
            time: "8:00 AM",
            title: "Heritage Site Visit",
            description: "Guided tour of UNESCO World Heritage sites.",
            type: "culture",
            isHiddenGem: false
          },
          {
            time: "12:00 PM",
            title: "Cooking Class with Local Family",
            description: "Learn to cook traditional dishes with a local family.",
            type: "experience",
            isHiddenGem: true
          },
          {
            time: "4:00 PM",
            title: "Artisan Workshop Visit",
            description: "Meet local craftspeople and see traditional art forms.",
            type: "culture",
            isHiddenGem: true
          }
        ]
      },
      {
        day: 3,
        title: "Adventure & Nature",
        location: tripData.destination,
        activities: [
          {
            time: "6:00 AM",
            title: "Sunrise Photography Tour",
            description: "Capture stunning sunrise views at iconic locations.",
            type: "photography",
            isHiddenGem: false
          },
          {
            time: "10:00 AM",
            title: "Nature Walk & Wildlife Spotting",
            description: "Guided nature walk in nearby national park.",
            type: "nature",
            isHiddenGem: false
          },
          {
            time: "3:00 PM",
            title: "Village Experience",
            description: "Visit a traditional village and interact with locals.",
            type: "culture",
            isHiddenGem: true
          }
        ]
      }
    ];

    return baseItinerary;
  };

  const itinerary = generateItinerary();

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'food': return <Utensils className="w-4 h-4" />;
      case 'culture': return <Star className="w-4 h-4" />;
      case 'photography': return <Camera className="w-4 h-4" />;
      case 'nature': return <MapPin className="w-4 h-4" />;
      case 'experience': return <Coffee className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'food': return 'bg-orange-100 text-orange-600';
      case 'culture': return 'bg-purple-100 text-purple-600';
      case 'photography': return 'bg-blue-100 text-blue-600';
      case 'nature': return 'bg-green-100 text-green-600';
      case 'experience': return 'bg-yellow-100 text-yellow-600';
      default: return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#36454F] text-white px-4 py-3 sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="flex items-center space-x-2">
            <ArrowLeft className="w-5 h-5 text-white" />
            <span className="text-white">Back</span>
          </button>
          <h1 className="text-lg font-semibold text-white">Your Itinerary</h1>
          <button onClick={handleShareItinerary}>
            <Share className="w-5 h-5 text-white" />
          </button>
        </div>
      </header>

      {/* Itinerary Header */}
      <div className="bg-gradient-to-r from-[#FF9933] to-[#e6851f] text-white px-4 py-6">
        <div className="flex items-center space-x-3 mb-4">
          <Calendar className="w-6 h-6" />
          <div>
            <h2 className="text-xl font-bold">{tripData?.destination} Adventure</h2>
            <p className="text-sm opacity-90">
              {tripData?.startDate} to {tripData?.endDate}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {tripData?.interests?.slice(0, 3).map((interest, index) => (
            <Badge key={index} variant="secondary" className="bg-white/20 text-white border-white/30">
              {interest}
            </Badge>
          ))}
        </div>

        <Button
          onClick={handleDownloadPDF}
          className="w-full bg-white text-[#FF9933] hover:bg-gray-100 font-semibold"
        >
          <Download className="w-4 h-4 mr-2" />
          Download PDF for Offline Access
        </Button>
      </div>

      {/* Safety Banner */}
      <div className="bg-red-50 border-l-4 border-red-400 p-4 mx-4 mt-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
              <span className="text-red-600 text-sm font-bold">!</span>
            </div>
            <div>
              <p className="text-sm font-medium text-red-800">Safety First</p>
              <p className="text-xs text-red-600">Check current advisories and emergency contacts</p>
            </div>
          </div>
          <Button
            onClick={() => onNavigate('safety')}
            size="sm"
            className="bg-red-600 hover:bg-red-700 text-white"
          >
            View Safety
          </Button>
        </div>
      </div>

      {/* Itinerary Days */}
      <div className="px-4 py-6 space-y-4">
        {itinerary.map((day) => (
          <Card key={day.day} className="overflow-hidden">
            <button
              onClick={() => setExpandedDay(expandedDay === day.day ? null : day.day)}
              className="w-full p-4 text-left flex items-center justify-between hover:bg-gray-50"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-[#FF9933] rounded-full flex items-center justify-center text-white font-bold">
                  {day.day}
                </div>
                <div>
                  <h3 className="font-semibold text-[#36454F]">{day.title}</h3>
                  <p className="text-sm text-gray-600">{day.location}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="text-xs">
                  {day.activities.length} activities
                </Badge>
                <div className={`transform transition-transform ${expandedDay === day.day ? 'rotate-180' : ''}`}>
                  ▼
                </div>
              </div>
            </button>

            {expandedDay === day.day && (
              <div className="border-t bg-gray-50 p-4 space-y-4">
                {day.activities.map((activity, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-16 text-xs text-gray-600 font-medium pt-1">
                      {activity.time}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center ${getActivityColor(activity.type)}`}>
                          {getActivityIcon(activity.type)}
                        </div>
                        <h4 className="font-medium text-[#36454F]">{activity.title}</h4>
                        {activity.isHiddenGem && (
                          <div className="flex items-center space-x-1">
                            <Gem className="w-4 h-4 text-[#FF9933]" />
                            <span className="text-xs text-[#FF9933] font-medium">Hidden Gem</span>
                          </div>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">{activity.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        ))}
      </div>

      {/* Tips Section */}
      <div className="px-4 pb-6">
        <Card className="p-4 bg-blue-50 border-blue-200">
          <h3 className="font-semibold text-[#36454F] mb-2">💡 Travel Tips</h3>
          <ul className="text-sm text-gray-700 space-y-1">
            <li>• Keep your passport and visa handy at all times</li>
            <li>• Download offline maps for each destination</li>
            <li>• Learn basic Hindi phrases for better local interaction</li>
            <li>• Always negotiate prices at markets</li>
            <li>• Drink bottled water and eat at recommended places</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { ArrowLeft, Shield, Phone, MapPin, AlertTriangle, CheckCircle, Clock, Navigation, Heart } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { toast } from 'sonner@2.0.3';

interface SafetyDashboardProps {
  onBack: () => void;
}

export function SafetyDashboard({ onBack }: SafetyDashboardProps) {
  const [sosPressed, setSosPressed] = useState(false);

  const handleSOSPress = () => {
    setSosPressed(true);
    toast("🚨 SOS Alert Activated! Emergency services have been notified. Stay calm, help is on the way.", {
      duration: 5000,
      style: {
        background: '#d4183d',
        color: 'white',
        fontSize: '14px'
      }
    });
    
    // Reset after 3 seconds for demo
    setTimeout(() => setSosPressed(false), 3000);
  };

  const handleEmergencyContact = (service: string, number: string) => {
    toast(`Calling ${service} at ${number}`, {
      duration: 2000,
      style: {
        background: '#36454F',
        color: 'white',
      }
    });
  };

  const emergencyContacts = [
    { name: 'Police', number: '100', icon: Shield, color: 'bg-blue-600' },
    { name: 'Medical Emergency', number: '108', icon: Heart, color: 'bg-red-600' },
    { name: 'Fire Department', number: '101', icon: AlertTriangle, color: 'bg-orange-600' },
    { name: 'Tourist Helpline', number: '1363', icon: Phone, color: 'bg-green-600' }
  ];

  const safetyAlerts = [
    {
      level: 'info',
      title: 'Weather Update',
      message: 'Light rain expected in Delhi. Carry an umbrella.',
      time: '2 hours ago',
      icon: CheckCircle
    },
    {
      level: 'warning',
      title: 'Area Advisory',
      message: 'Avoid Old Delhi market area due to heavy crowds.',
      time: '4 hours ago',
      icon: AlertTriangle
    },
    {
      level: 'info',
      title: 'Cultural Event',
      message: 'Festival celebration at India Gate today 6-9 PM.',
      time: '6 hours ago',
      icon: CheckCircle
    }
  ];

  const quickSafetyTips = [
    "Always inform someone about your whereabouts",
    "Keep emergency contacts saved in your phone",
    "Carry a copy of your passport and visa",
    "Use official taxi services or ride-sharing apps",
    "Avoid displaying expensive items publicly",
    "Stay in well-lit, populated areas at night"
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#36454F] text-white px-4 py-3 sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="flex items-center space-x-2">
            <ArrowLeft className="w-5 h-5 text-white" />
            <span className="text-white">Back</span>
          </button>
          <h1 className="text-lg font-semibold text-white">Safety Dashboard</h1>
          <div className="w-6"></div>
        </div>
      </header>

      {/* SOS Section */}
      <div className="bg-gradient-to-br from-red-50 to-red-100 px-4 py-8">
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold text-[#36454F] mb-2">Emergency Assistance</h2>
          <p className="text-gray-600">Press and hold for 3 seconds to activate SOS</p>
        </div>

        <div className="flex justify-center mb-6">
          <button
            onClick={handleSOSPress}
            className={`w-32 h-32 rounded-full font-bold text-xl transition-all duration-300 shadow-lg ${
              sosPressed 
                ? 'bg-red-700 text-white scale-110 shadow-red-300' 
                : 'bg-red-600 text-white hover:bg-red-700 hover:scale-105'
            }`}
          >
            {sosPressed ? (
              <div className="flex flex-col items-center">
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin mb-1"></div>
                <span className="text-sm">Alerting...</span>
              </div>
            ) : (
              'SOS'
            )}
          </button>
        </div>

        <div className="text-center">
          <p className="text-sm text-gray-600 mb-2">Your current location will be shared</p>
          <div className="flex items-center justify-center space-x-2 text-green-600">
            <Navigation className="w-4 h-4" />
            <span className="text-sm font-medium">Location Services: Active</span>
          </div>
        </div>
      </div>

      {/* Emergency Contacts */}
      <div className="px-4 py-6">
        <h3 className="text-lg font-semibold text-[#36454F] mb-4">Emergency Contacts</h3>
        <div className="grid grid-cols-2 gap-3">
          {emergencyContacts.map((contact, index) => (
            <Button
              key={index}
              onClick={() => handleEmergencyContact(contact.name, contact.number)}
              className={`${contact.color} hover:opacity-90 text-white p-4 h-auto flex flex-col items-center space-y-2`}
            >
              <contact.icon className="w-6 h-6" />
              <div className="text-center">
                <div className="font-semibold text-sm">{contact.name}</div>
                <div className="text-xs opacity-90">{contact.number}</div>
              </div>
            </Button>
          ))}
        </div>
      </div>

      {/* Safety Alerts */}
      <div className="px-4 pb-6">
        <h3 className="text-lg font-semibold text-[#36454F] mb-4">Safety Alerts & Updates</h3>
        <div className="space-y-3">
          {safetyAlerts.map((alert, index) => (
            <Card key={index} className={`p-4 border-l-4 ${
              alert.level === 'warning' ? 'border-orange-400 bg-orange-50' : 'border-green-400 bg-green-50'
            }`}>
              <div className="flex items-start space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  alert.level === 'warning' ? 'bg-orange-100' : 'bg-green-100'
                }`}>
                  <alert.icon className={`w-4 h-4 ${
                    alert.level === 'warning' ? 'text-orange-600' : 'text-green-600'
                  }`} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-semibold text-[#36454F]">{alert.title}</h4>
                    <Badge variant="outline" className="text-xs">
                      {alert.time}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-700">{alert.message}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Quick Safety Tips */}
      <div className="px-4 pb-6">
        <Card className="p-4 bg-[#36454F] text-white">
          <h3 className="font-semibold mb-3 text-white">🛡️ Quick Safety Tips</h3>
          <div className="space-y-2">
            {quickSafetyTips.map((tip, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-[#FF9933] rounded-full flex-shrink-0"></div>
                <p className="text-sm text-gray-200">{tip}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Current Status */}
      <div className="px-4 pb-8">
        <Card className="p-4 bg-green-50 border-green-200">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h4 className="font-semibold text-green-800">All Systems Operational</h4>
              <p className="text-sm text-green-600">Your safety monitoring is active</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
document.addEventListener('DOMContentLoaded', () => {
  const nextBtn = document.getElementById('next-btn-1');
  const destinationInput = document.getElementById('destination');
  const startDateInput = document.getElementById('start-date');
  const endDateInput = document.getElementById('end-date');

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      if (destinationInput.value && startDateInput.value && endDateInput.value) {
        localStorage.setItem('destination', destinationInput.value);
        localStorage.setItem('startDate', startDateInput.value);
        localStorage.setItem('endDate', endDateInput.value);
        window.location.href = 'plan-trip-2.html';
      } else {
        alert('Please fill in all the fields.');
      }
    });
  }
});

document.addEventListener('DOMContentLoaded', () => {
  const interests = document.querySelectorAll('.option-card');
  const nextBtn2 = document.getElementById('next-btn-2');
  const selectedCountSpan = document.getElementById('selected-count');

  if (interests.length > 0) {
    let selectedInterests = [];
    interests.forEach(card => {
      card.addEventListener('click', () => {
        const interest = card.dataset.interest;
        if (card.classList.contains('selected')) {
          card.classList.remove('selected');
          selectedInterests = selectedInterests.filter(item => item !== interest);
        } else {
          card.classList.add('selected');
          selectedInterests.push(interest);
        }
        selectedCountSpan.textContent = selectedInterests.length;
        nextBtn2.disabled = selectedInterests.length < 3;
        localStorage.setItem('selectedInterests', JSON.stringify(selectedInterests));
      });
    });
  }

  // ✅ Added navigation for Step 2 → Step 3
  if (nextBtn2) {
    nextBtn2.addEventListener('click', () => {
      window.location.href = 'plan-trip-3.html';
    });
  }

  const goals = document.querySelectorAll('.option-card-full');
  const nextBtn3 = document.getElementById('next-btn-3');
  const selectedCountGoalsSpan = document.getElementById('selected-count-goals');

  if (goals.length > 0) {
    let selectedGoals = [];
    goals.forEach(card => {
      card.addEventListener('click', () => {
        const goal = card.dataset.goal;
        if (card.classList.contains('selected')) {
          card.classList.remove('selected');
          selectedGoals = selectedGoals.filter(item => item !== goal);
        } else {
          card.classList.add('selected');
          selectedGoals.push(goal);
        }
        selectedCountGoalsSpan.textContent = selectedGoals.length;
        nextBtn3.disabled = selectedGoals.length < 2;
        localStorage.setItem('selectedGoals', JSON.stringify(selectedGoals));
      });
    });
  }

  // ✅ Added navigation for Step 3 → Step 4
  if (nextBtn3) {
    nextBtn3.addEventListener('click', () => {
      window.location.href = 'plan-trip-4.html';
    });
  }

  const generateBtn = document.getElementById('generate-itinerary-btn');

  if (generateBtn) {
    generateBtn.addEventListener('click', () => {
      const destination = localStorage.getItem('destination') || 'Your Trip';
      const startDate = localStorage.getItem('startDate');
      const endDate = localStorage.getItem('endDate');
      const interests = JSON.parse(localStorage.getItem('selectedInterests')) || [];

      const mockItinerary = {
        destination: destination,
        dates: `${startDate} to ${endDate}`,
        tags: interests,
        days: [
          {
            day: 1,
            title: 'Arrival & Local Exploration',
            activities: [
              { time: '10:00 AM', description: 'Airport Pickup & Hotel Check-in' }
            ]
          },
        ]
      };

      localStorage.setItem('generatedItinerary', JSON.stringify(mockItinerary));
      window.location.href = 'itineary.html';
    });
  }
});

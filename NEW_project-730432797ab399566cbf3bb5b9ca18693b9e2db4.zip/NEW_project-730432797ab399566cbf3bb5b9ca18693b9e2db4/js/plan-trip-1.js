document.addEventListener('DOMContentLoaded', () => {
    const nextBtn = document.getElementById('next-btn-1');
    const destinationInput = document.getElementById('destination');
    const startDateInput = document.getElementById('start-date');
    const endDateInput = document.getElementById('end-date');

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            if (destinationInput.value && startDateInput.value && endDateInput.value) {
                localStorage.setItem('destination', destinationInput.value);
                localStorage.setItem('startDate', startDateInput.value);
                localStorage.setItem('endDate', endDateInput.value);
                window.location.href = 'plan-trip-2.html';
            } else {
                alert('Please fill in all the fields.');
            }
        });
    }
});
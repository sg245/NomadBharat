document.addEventListener('DOMContentLoaded', () => {
  const itineraryData = JSON.parse(localStorage.getItem('generatedItinerary'));

  if (itineraryData) {
    document.getElementById('itinerary-destination').textContent = itineraryData.destination;
    document.getElementById('itinerary-dates').textContent = itineraryData.dates;

    const tagsContainer = document.getElementById('itinerary-tags');
    itineraryData.tags.forEach(tag => {
      const span = document.createElement('span');
      span.classList.add('tag');
      span.textContent = tag.charAt(0).toUpperCase() + tag.slice(1);
      tagsContainer.appendChild(span);
    });

    const contentContainer = document.getElementById('itinerary-content');
    itineraryData.days.forEach(day => {
      const dayDiv = document.createElement('div');
      dayDiv.classList.add('itinerary-day');
      dayDiv.innerHTML = `<h4>Day ${day.day}: ${day.title}</h4>`;

      const activitiesList = document.createElement('ul');
      day.activities.forEach(activity => {
        const activityLi = document.createElement('li');
        activityLi.innerHTML = `<span class="activity-time">${activity.time}</span> - ${activity.description}`;
        if (activity.tag) {
          activityLi.innerHTML += `<span class="activity-tag">${activity.tag}</span>`;
        }
        activitiesList.appendChild(activityLi);
      });
      dayDiv.appendChild(activitiesList);
      contentContainer.appendChild(dayDiv);
    });
  }
});
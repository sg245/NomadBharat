document.addEventListener('DOMContentLoaded', () => {
  const sosBtn = document.getElementById('sos-btn');
  let pressTimer;

  if (sosBtn) {
    sosBtn.addEventListener('mousedown', () => {
      pressTimer = setTimeout(() => {
        console.log('SOS activated!');
        alert('SOS signal sent! Your location has been shared with emergency contacts.');
      }, 3000);
    });
    sosBtn.addEventListener('mouseup', () => {
      clearTimeout(pressTimer);
    });

    sosBtn.addEventListener('touchstart', (e) => {
      e.preventDefault();
      pressTimer = setTimeout(() => {
        console.log('SOS activated!');
        alert('SOS signal sent!');
      }, 3000);
    });
    sosBtn.addEventListener('touchend', () => {
      clearTimeout(pressTimer);
    });
  }
});